"use client";
import React from "react";
import Image from "next/image";
import Link from "next/link";
import "@/styles/Navbar/Navbar.css";

const Navbar = () => {
  return (
    <nav>
      <div className="logo">
        <Image src="/logo.png" width={32} height={32} alt="Logo" />
        <h2>Kriger Studio</h2>
      </div>
      {/* <div className="links">
        <Link href="#about">ABOUT</Link>
        <Link href="#projects">PROJECTS</Link>
        <Link href="#contact">CONTACT US</Link>
      </div> */}
    </nav>
  );
};

export default Navbar;
