import React from "react";
import "@/styles/Attribution/Attribution.css";

const Attribution = () => {
  return (
    <div className="attribution">
      <a href="/">
        © 2021 Kriger Studio | All Rights Reserved
        <span className="bar"></span>
      </a>
    </div>
  );
};

export default Attribution;
