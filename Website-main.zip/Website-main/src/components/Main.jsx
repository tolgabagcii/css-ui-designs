import React from "react";
import ReactFullpage from "@fullpage/react-fullpage";
import '@/styles/Main/Main.css'
import About from "./About";
import Contact from "./Contact";

const anchors = ["about", /*"projects",*/ "contact"];
const tooltips = ["ABOUT", /*"PROJECTS",*/ "CONTACT"];

const Main = () => (
  <ReactFullpage
    anchors={anchors}
    navigation
    navigationTooltips={tooltips}
    onLeave={(origin, destination, direction) => {
      console.log("onLeave event", { origin, destination, direction });
    }}
    render={({ state, fullpageApi }) => {
      return (
        <div className="main">
          <About/>
          <Contact/>
          {/* <div className="section"><h3>Projects</h3></div>
          <div className="section"><h3>Contact Us</h3></div> */}
        </div>
      );
    }}
  />
);
export default Main;