"use client";
import { useForm, ValidationError } from "@formspree/react";
import Link from "next/link";
import "@/styles/Contact/Contact.css";

function ContactForm() {
  const [state, handleSubmit] = useForm("mvojzkze");
  if (state.succeeded) {
    return (
      <p style={{
        color: 'var(--green)',
        margin: '40px 0'
      }}>
        Thanks for contacting!
      </p>
    );
  }
  return (
    <form onSubmit={handleSubmit}>
      <input id="name" type="name" name="name" placeholder="Name" required />
      <ValidationError prefix="Name" field="name" errors={state.errors} />
      <input id="email" type="email" name="email" placeholder="E-mail" />
      <ValidationError prefix="Email" field="email" errors={state.errors} />
      <input id="topic" type="topic" name="topic" placeholder="Topic" required />
      <ValidationError prefix="Topic" field="topic" errors={state.errors} />
      <textarea id="message" name="message" placeholder="Message" />
      <ValidationError prefix="Message" field="message" errors={state.errors} />
      <button className="submit" type="submit" disabled={state.submitting}>
        Submit
      </button>
    </form>
  );
}

const Contact = () => {
  const [state, handleSubmit] = useForm("mvojzkze");
  if (state.succeeded) {
    return (
      <div className="status succes" id="status">
        Thanks for joining!
      </div>
    );
  }

  return (
    <div className="section contact">
      <div className="modules">
        <h1 className="title">
          Contact Us
          <span className="bar"></span>
        </h1>
        <h2 className="description">
          If you have something to share or any inquiries, please don&apos;t hesitate
          to contact us!
        </h2>
        <div className="links">
          <Link
            href="mailto:contact@krigerstudio.com"
            aria-label="Mail to us"
            target="_blank"
          >
            <i className="fa-regular fa-envelope"></i>
          </Link>
          <Link
            href="https://instagram.com/krigerstudio"
            aria-label="Go to our Instagram account"
            target="_blank"
          >
            <i className="fa-brands fa-instagram"></i>
          </Link>
          <Link
            href="https://www.facebook.com/profile.php?id=100093795990529"
            aria-label="Go to our Facebook account"
            target="_blank"
          >
            <i className="fa-brands fa-facebook-f"></i>
          </Link>
          <Link
            href="https://twitter.com/krigerstudio"
            aria-label="Go to our Twitter account"
            target="_blank"
          >
            <i className="fa-brands fa-twitter"></i>
          </Link>
        </div>
        <ContactForm />
      </div>
    </div>
  );
};

export default Contact;
