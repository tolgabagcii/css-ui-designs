import React from "react";
import "@/styles/About/About.css";
import Link from "next/link";

const About = () => {
  return (
    <div className="section about">
      <div className="modules">
        <h1 className="title">Kriger Studio</h1>
        <h2 className="description">
          Brings dreams to life through captivating games since 2021.
          <br />
          Experience the magic of our immersive creations.
        </h2>
        <div className="links">
          <Link href="#projects" aria-label="Go to Projects">
            <i className="fa-solid fa-gamepad"></i>
          </Link>
          <Link
            href="https://www.linkedin.com/company/krigerstudio/"
            aria-label="Go to our LinkedIn account"
            target="_blank"
          >
            <i className="fa-brands fa-linkedin-in"></i>
          </Link>
          <Link
            href="https://github.com/krigerstudio"
            aria-label="Go to our GitHub account"
            target="_blank"
          >
            <i className="fa-brands fa-github"></i>
          </Link>
        </div>
        <span className="frame"></span>
      </div>
    </div>
  );
};

export default About;
