import { metadata } from "../app/layout";

export default function Seo() {
  return (
    <head>
      <meta name="author" content="Kriger Studio" />
      <meta property="og:title" content={metadata.title} />
      <meta property="og:description" content={metadata.description} />
      <meta property="og:url" content="https://www.krigerstudio.com" />
      <meta property="og:site_name" content="Kriger Studio" />
      <link
        rel="apple-touch-icon"
        sizes="180x180"
        href="/apple-touch-icon.png"
      />
      <link
        rel="icon"
        type="image/png"
        sizes="32x32"
        href="/favicon-32x32.png"
      />
      <link
        rel="icon"
        type="image/png"
        sizes="16x16"
        href="/favicon-16x16.png"
      />
      <link rel="manifest" href="/site.webmanifest" />
      <link rel="mask-icon" href="/safari-pinned-tab.svg" color="#5bbad5" />
      <meta name="msapplication-TileColor" content="#da532c" />
      <meta name="theme-color" content="#000" />
      <meta property="og:type" content="website" />
      <meta
        property="og:title"
        content="Kriger Studio - Your Gateway to Gaming Excellence"
      />
      <meta
        property="og:description"
        content="Brings dreams to life through captivating games since 2021. Experience the magic of our immersive creations that resonate with players worldwide."
      />
      <meta property="og:url" content="https://www.krigerstudio.com" />
      <meta
        property="og:image"
        content="https://www.krigerstudio.com/banner.png"
      />
      <meta property="og:image:type" content="image/png" />
      <meta property="og:image:alt" content="Kriger Studio" />
      <meta property="og:image:width" content="1200" />
      <meta property="og:image:height" content="630" />
      <meta name="twitter:card" content="summary_large_image" />
      <meta name="twitter:site" content="@krigerstudio" />
      <meta
        name="twitter:title"
        content="Kriger Studio - Your Gateway to Gaming Excellence"
      />
      <meta
        name="twitter:description"
        content="Brings dreams to life through captivating games since 2021. Experience the magic of our immersive creations that resonate with players worldwide."
      />
      <meta name="twitter:creator" content="@krigerstudio" />
      <meta
        property="twitter:image"
        content="https://www.krigerstudio.com/banner.png"
      />
      <meta property="og:image:type" content="image/png" />
      <meta property="twitter:image:alt" content="Kriger Studio" />
      <meta property="twitter:image:width" content="1200" />
      <meta property="twitter:image:height" content="630" />
      <link rel="canonical" href="https://www.krigerstudio.com" />
    </head>
  );
}
