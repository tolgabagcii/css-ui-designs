"use client";
import React from "react";
import { Bars } from "react-loader-spinner";
import "./globals.css";

export default function Loading() {
  return (
    <Bars
      height="80"
      width="80"
      color="#ff6c00"
      ariaLabel="bars-loading"
      wrapperClass="loader flex items-center justify-center w-screen h-screen"
      visible={true}
    />
  );
}
