"use client";
import Navbar from "@/components/Navbar";
import Cursor from "@/components/Cursor";
import Attribution from "@/components/Attribution";
import Main from "@/components/Main";
import "./globals.css";

export default function Home() {
  return (
    <>
      <Navbar />
      <Main />
      <Cursor />
      <Attribution />
    </>
  );
}
