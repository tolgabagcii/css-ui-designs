import { Suspense } from "react";
import "./globals.css";
import Loading from "./loading";
import Seo from "../components/Seo";

export const metadata = {
  title: "Kriger Studio - Your Gateway to Gaming Excellence",
  description:
    "Brings dreams to life through captivating games since 2021. Experience the magic of our immersive creations that resonate with players worldwide.",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <Seo />
      <body>
        <Suspense fallback={<Loading />}>{children}</Suspense>
      </body>
    </html>
  );
}
